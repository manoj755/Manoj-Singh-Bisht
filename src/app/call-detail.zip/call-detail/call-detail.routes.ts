import { Routes } from '@angular/router';
import { CallDetailComponent } from '../call-detail/call-detail.component';

export const CallDetailRoutes: Routes = [{
  path: '',
  component: CallDetailComponent
}]
