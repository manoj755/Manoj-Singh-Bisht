//import { Component, OnInit, NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { HistoryComponent } from '../history/history.component';

export const HistoryRoutes: Routes = [{
  path: '',
  component: HistoryComponent
}]
