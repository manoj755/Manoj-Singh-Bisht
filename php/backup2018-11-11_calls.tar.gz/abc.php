<?php

ini_set('display_errors', 1);
error_reporting(E_ALL); 
$destination="/var/spool/asterisk/outgoing/";
$source="/var/lib/asterisk/agi-bin/php/calls_files/";
$noofcallfile=0;
if (is_dir($destination)){
  if ($dh = opendir($destination)){
    while (($file = readdir($dh)) !== false){
        if(strpos($file, '.call') !== false){
          $noofcallfile=$noofcallfile+1;
        }
      
    }
    closedir($dh);
  }
}

$noofport=4;
$noofcallfile=$noofport-$noofcallfile;
include '/var/lib/asterisk/agi-bin/php/lib/call.php';
$call=new Call();
include 'process_call.php';



function SendCall($called_number,$callid){


 
    // $called_number='9999689919';
    // $callid='328';
    
    //shell_exec('sudo asterisk -rx " originate SIP/'.$mobilenumber.'@GSM extension s@allPR"');
    
    //$fullpath='';
    $filename="/var/lib/asterisk/agi-bin/php/calls_files/{$called_number}_$callid.call";
    $myfile = fopen("$filename", "w");
    
    $txt =
"Channel: SIP/GSM/$called_number
Context: allPR
RetryTime: 30
MaxRetries: 1
Extension:s
Set: called_number=$called_number
Set: callid=$callid
Set: failed=0
Priority:1
Archive:Yes";
    fwrite($myfile, $txt);
    fclose($myfile);

    
    }
    

$stmt= $call->readToCall(0,$noofcallfile);

while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
  
    
    SendCall($row['mobile'],$row['id']);
    

    $call->readOne($row['id']);
    $call->call_status='callrequestsent';
    $call->save();


}

// Get array of all source files
$files = scandir($source);
//var_dump($files);
// Identify directories
$delete=[];
// Cycle through all source files
foreach ($files as $file) {
  if (in_array($file, array(".",".."))) continue;
  // If we copied this successfully, mark it for deletion
  if (copy($source.$file, $destination.$file)) {
    $delete[] = $source.$file;
  }
}
// Delete all successfully-copied files
foreach ($delete as $file) {
  unlink($file);
}
 
    

include_once 'syncdata/getdata.php';
include_once 'syncdata/updatedata.php';

?>
