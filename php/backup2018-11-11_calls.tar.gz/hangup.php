#!/usr/bin/php
<?php
//include 'custom_function.php';
include '/var/lib/asterisk/agi-bin/php/lib/call.php';
$call=new Call();

//error_reporting(E_ALL);
require_once 'vendor/autoload.php';
$pagiClientOptions = array();
//execute_agi("SET VARIABLE ScriptResult test");
use PAGI\Client\Impl\ClientImpl as PagiClient;
$pagiClient = PagiClient::getInstance($pagiClientOptions);


$reasoncode=$pagiClient->getVariable('reason');
$reason='error';

// 0 - Failed (not busy or congested)
// 1 - Hung up
// 3 - Ring timeout
// 5 - Busy
// 8 - Congestion

switch($reasoncode){
    case "0":
    $reason='Failed';
    break;
    case "1":
    $reason='Hung up';
    break;
    case "3":
    $reason='Ring timeout';
    break;
    case "5":
    $reason='Busy';
    break;
    case "8":
    $reason='Congestion';
    break;
    default:
    $reason=$reasoncode;
    
    

}

if(trim($reason)!=''){
$call->readOne($pagiClient->getVariable('callid'));
$call->call_status=$reason;
$call->save();
}





?>