#!/usr/bin/php
<?php







ini_set('display_errors', 1);
error_reporting(E_ALL); 


 


// include 'lib/call.php';
// $call=new Call();
// $call->readOne(328);
// var_dump(json_decode($call->custom_data)->first_name);
// exit();
// $stmt=$call->readAll();
// $num = $stmt->rowCount();
// echo $num;

// while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
 
//     extract($row);
    
//     echo $custom_data;
// }




// exit();
// require 'custom_functions.php';

//  echo  "_".$tts->convert_tts('hi howd are you friends','en','1')."_";
//  exit();

class pagiClient{

    

    public function getVariable($type){

        if($type=='utterance'){
       return '';
        }else if($type== 'event'){
            return 'NewCall';
        }else if($type== 'questionid'){
            return "0";
        }

    }
    public function setVariable($t,$ts){

    }

    public function hangUp()
    {
        
    }


}
$istest=true;


$pagiClient=new pagiClient();

include 'interview.php';

//include 'processspeech.php';




// [allPR]
// exten => s,1,agi(php/call_type.php)
// exten => s,n(processanswer),agi(php/app.php)
// exten => s,n,eagi(googletts.agi,${speech},en)
// exten => s,n(record),eagi(speech-recog.agi,en,2,#,NOBEEP)
// exten => s,n,Verbose(1,Script returned: ${confidence} , ${utterance})
// exten => s,n,Goto(s,processanswer)
// exten => s,n,Hangup()