<?php



error_reporting(E_ALL);
include 'IVR/FirstInterviewHelper.php';
$firstInterView=new FirstInterviewHelper();
//var_dump($firstInterView->questions);
$data=array('test'=>'','event'=>'NewCall','questionid'=>1,'data'=>'');

