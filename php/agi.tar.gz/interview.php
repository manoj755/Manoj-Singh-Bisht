<?php
include 'IVR/FirstInterviewHelper.php';
$firstInterView=new FirstInterviewHelper();
//var_dump($firstInterView->questions);



$utterance=$pagiClient->getVariable('utterance');
$result=array();
//echo $utterance;
if($utterance=='-1' || trim($utterance)!=''){
    $data=array('test'=>'','event'=>$pagiClient->getVariable('event'),'questionid'=>$pagiClient->getVariable('questionid'),'data'=>$utterance);
    if(isset($istest)){
    print_r($data);   
    echo '<br/>';
    } 
    $result=$firstInterView->process_talk($data);
    if(isset($istest)){
        echo '<br/>';
        var_dump($result);
        echo '<br/>';
    }


    $pagiClient->setVariable('questionid',$result['questionid']);
    $speech='';
    $msg=$result['msg'];
    if(is_array($msg)){
    foreach ($msg as $template) {
        if ($template['type'] == 'text'  ) {
            $speech.=' '.$template['data'];
        } else if ($template['type'] == 'audio') {
            $speech.=' '.$template['text'];
            //$r->addPlayAudio($url . $template['data'] . $ext);
        }
    }
}else{
    var_dump($msg);
}
    $speech=str_replace(',',' .',$speech);
    //echo  $speech;
    if($result['is_disconnect']){
        $pagiClient->hangUp();
    }



    $pagiClient->setVariable('speech',$speech);
    
    $pagiClient->setVariable('event','continue');
    

}else if(trim($utterance)=='')
{
    $pagiClient->setVariable('speech',"Please try again.");
    
}


$pagiClient->setVariable("utterance", "");





































//$result = dial("SIP/GSM/9999689919", array(60, 'rh'));
//$asteriskLogger = $pagiClient->getAsteriskLogger();
//$seconds=5;

//$pagiClient->answer();

//$result = $pagiClient->waitDigit(10000);
//$asteriskLogger->verbose($result);
//$pagiClient->saySound('max-attempts-reached');
//print $result;
//$pagiClient->sayDigits(2);
//$pagiClient->playDialTone();
//$pagiClient->playCongestionTone($seconds);
//execute_agi("SET VARIABLE ScriptResult test");
//$pagiClient->setVariable("ScriptResult", "somethinggreat");
//$pagiClient->setVariable("calltype", $pagiClient->getVariable('calltype').'anuj');


//$pagiClient->playBusyTone($seconds);
//$pagiClient->hangup();
//echo “SET VARIABLE ScriptResult narender”;

?>
