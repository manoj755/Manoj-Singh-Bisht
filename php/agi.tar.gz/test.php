#!/usr/bin/php
<?php
ini_set('display_errors', 1); error_reporting(E_ALL); 
require 'custom_functions.php';
class pagiClient{


    public function getVariable($type){

        if($type=='utterance'){
       return 'yes';
        }else if($type== 'event'){
            return 'continue';
        }else if($type== 'questionid'){
            return "2";
        }

    }
    public function setVariable($t,$ts){

    }


}
//$istest=true;


$pagiClient=new pagiClient();

include 'interview.php';


// [allPR]
// exten => s,1,agi(php/call_type.php)
// exten => s,n(processanswer),agi(php/app.php)
// exten => s,n,eagi(googletts.agi,${speech},en)
// exten => s,n(record),eagi(speech-recog.agi,en,2,#,NOBEEP)
// exten => s,n,Verbose(1,Script returned: ${confidence} , ${utterance})
// exten => s,n,Goto(s,processanswer)
// exten => s,n,Hangup()