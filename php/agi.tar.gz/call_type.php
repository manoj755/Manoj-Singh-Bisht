#!/usr/bin/php
<?php
//include 'custom_function.php';
error_reporting(E_ALL);
require_once 'vendor/autoload.php';
$pagiClientOptions = array();
//execute_agi("SET VARIABLE ScriptResult test");
use PAGI\Client\Impl\ClientImpl as PagiClient;
$pagiClient = PagiClient::getInstance($pagiClientOptions);


$pagiClient->setVariable("calltype", "interiview");
$pagiClient->setVariable("callid", "1");
$pagiClient->setVariable("utterance", "-1");
$pagiClient->setVariable("questionid", "1");
$pagiClient->setVariable('event','NewCall');
//$pagiClient->setVariable('speech','');





?>