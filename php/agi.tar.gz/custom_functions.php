<?php 
  function str_contains($string,$find )
  {
      $pos = strpos($string, $find);
      if($pos !== false){
          return true;
      }else{
          return  false;

      }
  }

?>