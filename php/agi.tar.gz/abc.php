<?php

$mobilenumber='9999689919';

//shell_exec('sudo asterisk -rx " originate SIP/'.$mobilenumber.'@GSM extension s@allPR"');
	
?>
